@echo off
setlocal
cd /d "%~dp0"
title GestLycee 7 - System

echo ==========================================
echo    GestLycee 7 - Starting System
echo ==========================================

REM Check if Node.js is available
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Node.js is not found. Please install Node.js.
    pause
    exit /b
)

REM Check for node_modules
if not exist "node_modules\" (
    echo INFO: Installing dependencies, please wait...
    call npm install
)

REM Open the browser after 5 seconds
echo INFO: Launching browser and server...
start /b "" cmd /c "timeout /t 5 >nul && start http://localhost:3000"

REM Start the application
call npm run dev

if %errorlevel% neq 0 (
    echo.
    echo ERROR: The application failed to start.
    echo Please check if port 3000 is already in use.
    echo.
    pause
)
