@echo off
setlocal
cd /d "%~dp0"

set "VBS_PATH=%~dp0run-hidden.vbs"
set "BAT_PATH=%~dp0start-app.bat"
set "DESKTOP_PATH=%USERPROFILE%\Desktop"
set "SHORTCUT_NAME=GestLycee.lnk"

echo ==========================================
echo    GestLycee 7 - Desktop Shortcut Setup
echo ==========================================

if not exist "%VBS_PATH%" (
    echo ERROR: run-hidden.vbs not found!
    pause
    exit /b
)

echo INFO: Unblocking files to prevent security warnings...
powershell -Command "Unblock-File -Path '%VBS_PATH%'"
powershell -Command "Unblock-File -Path '%BAT_PATH%'"

echo INFO: Creating silent desktop shortcut...

:: Create a shortcut that calls wscript.exe explicitly
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%DESKTOP_PATH%\%SHORTCUT_NAME%');$s.TargetPath='wscript.exe';$s.Arguments='\"%VBS_PATH%\"';$s.WorkingDirectory='%~dp0';$s.IconLocation='shell32.dll,249';$s.Save()"

if %errorlevel% equ 0 (
    echo SUCCESS: Silent shortcut created on your desktop!
) else (
    echo ERROR: Failed to create shortcut.
)

echo.
pause
